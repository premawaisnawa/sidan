<?php

$config = array(
  'protocol' => 'smtp',
  'smtp_host' => 'smtp.gmail.com',
  'smtp_port' => 465,
  'smtp_user' => "marketplacesilver@gmail.com",
  'smtp_pass' => "34GVvbl97Gpq",
  'mailtype' => "html",
  'charset' => 'iso-8859-1',
  'crlf' => "\r\n",
  'newline' => "\r\n",
  'validate' => TRUE,
  'wordwrap' => TRUE,
  'smtp_crypto' => 'ssl'
);
//smtp.live.com  'smtp_crypto' => 'ssl'
//smtp-mail.outlook.com
?>  

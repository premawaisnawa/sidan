<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>TicketCode :<?php echo $service[0]->TicketCode; ?></h1>
    <h1>Date :<?php echo $service[0]->StartTime; ?></h1>
    <h1>Email :<?php echo $service[0]->CustomerEmail; ?></h1>
    <h1>Phone :<?php echo $service[0]->PhoneNumber; ?></h1>

  </body>
</html>

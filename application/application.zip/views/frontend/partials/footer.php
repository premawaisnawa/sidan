<footer id="main-footer" style="background-color: black" class="text-white p-3 mt-5">
    <div class="container">
        <h2>Where to Find us ?</h2>
        <div class="row mt-4">
            <div class="col-md-4">
                <p class="lead"><span class="mr-2"><I class="fa fa-phone"></I></span>082312312</p>
                <p class="lead"><span class="mr-2"><I class="fa fa-envelope"></I></span>sidan@gmail.com</p>
                <p class="lead"><span class="mr-2"><I class="fa fa-location-arrow"></I></span>Jln. Tukad Pakerisan no.52
                </p>
            </div>
            <div class="col-md-4">
                <p class="text-center"><img style="height: 150px"
                                            src="http://stiki-indonesia.ac.id/wp-content/themes/stikiindo/img/map.jpg"
                                            class="img-fluid" alt="Google Map location"></p>
                <p class="text-center"><span><i class="fa fa-location-arrow">SIDAN's Office</i></span></p>
            </div>
            <div class="col-md-4 text-center">
                <p class="h5">Find Us on Social Medias</p>
                <p>
                    <span class="mx-3 display-4"><i class="fa fa-instagram"></i></span>
                    <span class="mx-3 display-4"><i class="fa fa-facebook-square"></i></span>
                    <span class="mx-3 display-4"><i class="fa fa-twitter"></i></span>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p class="lead text-center">Copyright &copy; 2018 SIDAN</p>
            </div>
        </div>
    </div>
</footer>
</body>
</html>
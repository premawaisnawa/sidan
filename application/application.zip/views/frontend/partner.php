<section class="container my-5">
<<<<<<< HEAD
    <div class="row text-center my-5 wow fadeInUp">
        <div class="col-md-3 sidan-shadow">
            <a href="<?php echo site_url('User/company_mini_site_view'); ?>"><img src="<?php echo base_url()?>public/images/mcd.png" alt="" class="img-fluid sidan-img-size"></a> 
=======
    <div class="row text-center my-0 my-lg-5 wow fadeInUp">
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/mcd.png" alt="" class="img-fluid sidan-img-size">
>>>>>>> origin/frontend-v2
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/samsung.jpg" alt="" class="img-fluid sidan-img-size">
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/apple.png" alt="" class="img-fluid sidan-img-size">
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/telkomsel.png" alt="" class="img-fluid sidan-img-size">
        </div>
    </div>
    <div class="row text-center my-0 my-lg-5 wow fadeInUp" data-wow-delay=".5s">
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/indosat.jpg" alt="" class="img-fluid sidan-img-size">
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/jco.png" alt="" class="img-fluid sidan-img-size">
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/pizzahut.png" alt="" class="img-fluid sidan-img-size">
        </div>
        <div class="col-md-3 sidan-shadow mx-5 mx-lg-0">
            <img src="<?php echo base_url() ?>public/images/kfc.png" alt="" class="img-fluid sidan-img-size">
        </div>
    </div>
</section>

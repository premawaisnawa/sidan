
</div><!-- /.content-wrapper -->

<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.0
    </div>
    <strong>Copyright &copy; 2017 <a href="http://almsaeedstudio.com">SIDAN</a>.</strong> All rights reserved.
</footer>
</div><!-- ./wrapper -->

</footer>
    </body>
</html>
<script src="http://malsup.github.io/jquery.blockUI.js" type="text/javascript"></script>

 <?php //.$this->load->view('template/back/msg_sukses'); ?>

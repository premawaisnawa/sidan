<!DOCTYPE html>
<html>
<head>
  <title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php $this->load->view('template/back_page/admin_lte_css'); ?>
<?php $this->load->view('template/back_page/admin_lte_js'); ?>
</head>
<body class="hold-transition skin-red sidebar-mini">
